# Density-based-Traffic-Control-System

In this project, images from four different lanes are taken and with the help of image processing , number of vehicles in each lane is being calculated.
A decision making algorithm is being designed which will calculate the time for which a lane will be active.
It is a dynamic system in which raspberry pi is used as master and four arduinos on each lane are used as slaves.

Technologies Used - Python, C
